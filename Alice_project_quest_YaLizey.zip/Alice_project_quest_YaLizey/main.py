from flask import Flask, request, jsonify
from flask_ngrok import run_with_ngrok
import logging

app = Flask(__name__)
run_with_ngrok(app)

logging.basicConfig(level=logging.INFO)

sessionStorage = {}
global type_place, num_place, scaf, power
@app.route('/post', methods=['POST'])
def main():
    with open('settings.txt', 'r') as f:
        for line in f:
            param = line.split()
        type_place = param[0]
        num_place = param[1]
        scaf = param[2]
        power = param[3]
    logging.info(f'Request: {request.json!r}')

    response = {
        'session': request.json['session'],
        'version': request.json['version'],
        'response': {
            'end_session': False,
            'text': 'Вы просыпаетесь в своей комнате на марсианской базе. Вроде всё как обычно, но вы чувствуете' /
                    'что - то неладное(Внимание если это сообщение появилось во время игры то значит я не дописал'
                    'диалог или вы выбрали несуществующее действие)'
        }
    }

    handle_dialog(request.json, response, type_place, num_place, scaf, power)

    logging.info(f'Response:  {response!r}')

    return jsonify(response)

def safe_1(req, res, power):
    a = req['request']['original_utterance'].lower().split()
    cows = 0
    no_cows = 0
    if len(a) != 4:
        res['response']['text'] = 'Неккоректный пароль'
    elif a[0] == 'один':
        no_cows += 1
    elif 'один' in a:
        cows += 1
    if a[1] == 'два':
        no_cows += 1
    elif 'два' in a:
        cows += 1
    if a[2] == 'три':
        no_cows += 1
    elif 'три' in a:
        cows += 1
    if a[3] == 'четыре':
        no_cows += 1
    elif 'четыре' in a:
        cows += 1
    if no_cows == 4:
        res['response']['text'] = 'Пароль верный, подача элетроэнергии включена - загорелось на компьютере, и в тот' \
                                  'же момент дверь начала закрываться, вы заметили отсутствие кнопки открытия' \
                                  'дверей изнутри и поспешили в коридор. Прямо или направо?'
        return True
    else:
        res['response']['text'] = f'Чисел которые присутствуют в пароле, но не на своём месте:{cows}' \
                                  f'Чисел присутствующих в пароле и стоящих на своём месте:{no_cows}'
        return False






def room_1(req, res):
    if 'осмотреться' in req['request']['original_utterance'].lower():
        print('eng')
        res['response']['text'] = 'Самая обычная спальная комната в углу стоит кровать а через окно видны безкрайние ' \
                                  'просторы марса'
    if 'выйти' in req['request']['original_utterance'].lower():
        res['response']['text'] = 'Вы покинули комнату и пошли прямо по коридору в конце которого была развилка прямо' \
                                  ' выход с базы налево рабочая комната а направо... Стоп раньше двери направо не было!'

def cor_1(req, res, scaf, power):
    if 'налево' in req['request']['original_utterance'].lower():
        res['response']['text'] = 'Вы нажимаете на кнопку и дверь в кабинет открывается и первая ваша мысль: что здесь'\
                                  'произошло? Вы помните что раньше это место было переполнено бумагами и' \
                                  ' компьютерами с кучей датчиков, но сейчас тут стоит один компьютер и листок с' \
                                  ' надписью пароль состоит из четырёх цифр'
    if 'направо' in req['request']['original_utterance'].lower():
        if power == 'true':
            res['response']['text'] = 'Вы заходите в неизвестную вам комнату... Первые ваши вопросы не заставили себя' \
                                      'долго ждать. Что это такое!? Посреди комнаты стояло странное устройство' \
                                      'похожее на скафандр рядом была записка в которой написано: "Это устройство' \
                                      'посреди комнаты как ты и подумал является скафандром, он поможет тебе ' \
                                      'уйти с этой проклятой планеты P.S. НЕ ЗАДЕРЖИВАЙСЯ НИ НА СЕКУНДУ!!!"' \
                                      ' Это сообщение мягко говоря испугало вас, и по инструкции приложеной к, ' \
                                      'скафандру вы его одели и вышли на бескрайние просторы марса...' \
                                      'Красные просторы марса так и тянут к себе, но вам нет дела до' \
                                      'этого ведь вы увидели то во что превратилась некогда процветающая база' \
                                      'все жилые блоки разрушены , а исследовательский комплекс зарос растениями' \
                                      'целым остался только склад... Продолжение следует'
        else:
            res['response']['text'] = 'Вы подходите к неизвестной двери, нажимаете на кнопку, но ничего не происходит.'\
                                        'она обесточена - понимаете вы'
    if 'прямо' in req['request']['original_utterance'].lower():
         res['response']['text'] = 'Вы считаете что выходить с базы без скафандра не самая лучшая идея'


def room_2(req, res):
    if 'назад' in req['request']['original_utterance'].lower():
        res['response']['text'] = 'Вы вернулись в коридор налево, направо или прямо?'
    if 'компьютер' in req['request']['original_utterance'].lower():
        res['response']['text'] = 'Вы подходите к компьютеру, он требует пароль'


def handle_dialog(req, res, type_place, num_place, scaf, power):
    user_id = req['session']['user_id']
    print(type_place, num_place)
    if type_place == 'room':
        if num_place == '1':
            room_1(req, res)
            if 'выйти' in req['request']['original_utterance'].lower():
                type_place = 'cor'
                num_place = '1'
        if num_place == '2':
            room_2(req, res)
            if 'назад' in req['request']['original_utterance'].lower():
                type_place = 'cor'
                num_place = '1'
            if 'компьютер' in req['request']['original_utterance'].lower():
                type_place = 'safe'
                num_place = '1'
    elif type_place == 'cor':
        if num_place == '1':
            cor_1(req, res, scaf, power)
            if 'направо' in req['request']['original_utterance'].lower():
                if power == 'true':
                    type_place = 'room'
                    num_place = '1'
                    scaf = 'false'
                    power = 'false'
                    with open('settings.txt', 'w') as f:
                        a = [type_place, num_place, scaf, power]
                        f.write(' '.join(a))
            if 'вернуться' in req['request']['original_utterance'].lower():
                type_place = 'room'
                num_place = '1'
            if 'налево' in req['request']['original_utterance'].lower():
                type_place = 'room'
                num_place = '2'
    elif type_place == 'safe':
        if num_place == '1':
            if safe_1(req, res, power):
                type_place = 'cor'
                num_place = '1'
                power = 'true'
    print(type_place, num_place)
    f = open('settings.txt', 'r+')
    f.truncate(0)
    f.close()
    with open('settings.txt', 'w') as f:
        a = [type_place, num_place, scaf, power]
        f.write(' '.join(a))




if __name__ == '__main__':
    app.run()